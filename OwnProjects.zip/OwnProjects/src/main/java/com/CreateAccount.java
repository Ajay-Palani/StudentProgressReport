package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/signup")
public class CreateAccount extends HttpServlet{
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException {
		String uname=req.getParameter("uname");
		String email=req.getParameter("email");
		String phone=req.getParameter("phone");
		String password=req.getParameter("password");
		String cpassword=req.getParameter("cpassword");
		
		PrintWriter out=res.getWriter();
		
		if(password!=cpassword) {
			out.print("<h3 style=color:'red'>Confirm Password should be same as your Password</h3>");
			RequestDispatcher dispatcher=req.getRequestDispatcher("signup.html");
			dispatcher.include(req, res);
		}
		
		GsmsDetails g=new GsmsDetails();
		DbGsms d=new DbGsms();
		g.setUname(uname);
		g.setEmail(email);
		g.setPhone(Long.parseLong(phone));
		g.setPassword(password);
		g.setCpassword(cpassword);			
		
		
		d.saveUser(g);
		RequestDispatcher dispatcher=req.getRequestDispatcher("Gsms.jsp");
		dispatcher.forward(req, res);
	}
}

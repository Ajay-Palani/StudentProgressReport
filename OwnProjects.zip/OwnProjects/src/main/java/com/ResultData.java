package com;

import java.io.IOException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/tenthresult")
public class ResultData extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String regno = req.getParameter("regno");
        String std = req.getParameter("std");

        EntityManagerFactory emf = null;
        EntityManager em = null;
        
		if (std.equals("ten")) {
			emf = Persistence.createEntityManagerFactory("dev");
			em = emf.createEntityManager();
			Query q = em.createQuery("select t from Ten t where t.regno=:regno", Ten.class);
			q.setParameter("regno", Integer.parseInt(regno));
			List<Ten> al = q.getResultList();
			req.setAttribute("Tenth", al);
			RequestDispatcher dispatcher = req.getRequestDispatcher("Result.jsp");
			dispatcher.forward(req, resp);
		} else if (std.equals("eleven")) {
			emf = Persistence.createEntityManagerFactory("dev1");
			em = emf.createEntityManager();

			Query qBio = em.createQuery("select b from Biology b where b.regno=:regno", Biology.class);
			qBio.setParameter("regno", Integer.parseInt(regno));
			List<Biology> bio = qBio.getResultList();
			req.setAttribute("bioresult", bio);

			Query qCs = em.createQuery("select cs from ComputerScience cs where cs.regno=:regno",
					ComputerScience.class);
			qCs.setParameter("regno", Integer.parseInt(regno));
			List<ComputerScience> cs = qCs.getResultList();
			req.setAttribute("CsResult", cs);

			Query qCom = em.createQuery("select c from Commerce c where c.regno=:regno", Commerce.class);
			qCom.setParameter("regno", Integer.parseInt(regno));
			List<Commerce> c = qCom.getResultList();
			req.setAttribute("ComResult", c);

			RequestDispatcher dispatcher2 = req.getRequestDispatcher("ElevenBioResult.jsp");
			dispatcher2.forward(req, resp);
        } else if (std.equals("twelve")) {
			emf = Persistence.createEntityManagerFactory("dev2");
			em = emf.createEntityManager();

			Query qBio = em.createQuery("select b from Biology b where b.regno=:regno", Biology.class);
			qBio.setParameter("regno", Integer.parseInt(regno));
			List<Biology> bio = qBio.getResultList();
			req.setAttribute("bioresult", bio);

			Query qCs = em.createQuery("select cs from ComputerScience cs where cs.regno=:regno",
					ComputerScience.class);
			qCs.setParameter("regno", Integer.parseInt(regno));
			List<ComputerScience> cs = qCs.getResultList();
			req.setAttribute("CsResult", cs);

			Query qCom = em.createQuery("select c from Commerce c where c.regno=:regno", Commerce.class);
			qCom.setParameter("regno", Integer.parseInt(regno));
			List<Commerce> c = qCom.getResultList();
			req.setAttribute("ComResult", c);

			RequestDispatcher dispatcher2 = req.getRequestDispatcher("TwelvethResult.jsp");
			dispatcher2.forward(req, resp);
        } 
    }
}

package com;


import java.sql.*;
import java.util.ArrayList;

public class DbGsms {
	public static Connection establishConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection c =DriverManager.getConnection("jdbc:mysql://localhost:3306/gsms_db","root", "root");
			return c;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void saveUser(GsmsDetails g) {
		Connection c=establishConnection();
		
		try {
			PreparedStatement ps= c.prepareStatement("insert into login values(?, ?, ?, ?, ?)");
			ps.setString(1, g.getUname());
			ps.setString(2, g.getEmail());
			ps.setLong(3, g.getPhone());
			ps.setString(4, g.getPassword());
			ps.setString(5, g.getCpassword());
			System.out.println("Data Saved");
			ps.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public GsmsDetails fetchUserByLogin(String Email, String Password) {
		Connection c=establishConnection();
		try {
			PreparedStatement ps= c.prepareStatement("select * from login where Email=? and Password=?");
			ps.setString(1, Email);
			ps.setString(2, Password);
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				GsmsDetails d=new GsmsDetails();
				d.setUname(rs.getString("UserName"));
				d.setEmail(rs.getString("Email"));
				d.setPhone(Long.parseLong(rs.getString("Phone")));
				d.setPassword(rs.getString("Password"));
				d.setPassword(rs.getString("Confirm Password"));
					
				return d;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList <User> getAll(){
		Connection c=establishConnection();
		
		try {
			Statement s=c.createStatement();
			
			ResultSet rs=s.executeQuery("select * from user");
			
			ArrayList <User> al =new ArrayList<>();
			
			while(rs.next()) {
				int id1=rs.getInt(1);
				String fname=rs.getString(2);
				String lname= rs.getString(3);
				String gender= rs.getString(4);
				String email= rs.getString(5);
				String pass= rs.getString(6);
				long phone =rs.getLong(7);
				
				User u=new User();
				al.add(u);
			}return al;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}

package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/ten")
public class TenServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String regno=req.getParameter("regno");
		String name=req.getParameter("sname");
		String tamil=req.getParameter("tamil");
		String english=req.getParameter("english");
		String maths=req.getParameter("maths");
		String science=req.getParameter("science");
		String social=req.getParameter("social");
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("dev");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Ten ten = new Ten();
		ten.setRegno(Integer.parseInt(regno));
		ten.setName(name);
		ten.setTmarks(Double.parseDouble(tamil));
		ten.setEmarks(Double.parseDouble(english));
		ten.setMmarks(Double.parseDouble(maths));
		ten.setSmarks(Double.parseDouble(science));
		ten.setSsmarks(Double.parseDouble(social));
		double total = ten.getTmarks() + ten.getEmarks() + ten.getMmarks() + ten.getSmarks() + ten.getSsmarks();
		ten.setTotal(total);

		et.begin();
		em.persist(ten);
		et.commit();
		
		RequestDispatcher dispatcher=req.getRequestDispatcher("fetchAll");
		dispatcher.forward(req, resp);
		
		
	}
}

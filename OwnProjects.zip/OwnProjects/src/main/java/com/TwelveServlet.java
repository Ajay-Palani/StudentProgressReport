package com;

import java.io.IOException;
import java.io.PrintWriter;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/twelve1")
public class TwelveServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String regno = req.getParameter("regno");
        String name = req.getParameter("name");
        String tamil = req.getParameter("tamil");
        String english = req.getParameter("english");
        String stream = req.getParameter("stream");
        String physics = req.getParameter("physics");
        String chemistry = req.getParameter("chemistry");
        String biology = req.getParameter("biology");
        String maths = req.getParameter("maths");
        String computer = req.getParameter("computer");
        String commerce = req.getParameter("commerce");
        String acc = req.getParameter("accounts");
        String eco = req.getParameter("eco");
        String bm = req.getParameter("bm");

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("dev2");
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        if (stream == null) {
            PrintWriter out = resp.getWriter();
            out.print("<script>alert('Invalid Option')</script>");
            return;
        }

        switch (stream) {
            case "biology":{
                Biology bio = new Biology();
                bio.setRegno(Integer.parseInt(regno));
                bio.setName(name);
                bio.setTmarks(Double.parseDouble(tamil));
                bio.setEmarks(Double.parseDouble(english));
                bio.setMmarks(Double.parseDouble(maths));
                bio.setPmarks(Double.parseDouble(physics));
                bio.setCmarks(Double.parseDouble(chemistry));
                bio.setBmarks(Double.parseDouble(biology));
                double totalBio = bio.getTmarks() + bio.getEmarks() + bio.getMmarks() + bio.getPmarks() + bio.getCmarks() + bio.getBmarks();
                bio.setTotal(totalBio);

                et.begin();
                em.persist(bio);
                et.commit();
                RequestDispatcher dispatcher=req.getRequestDispatcher("TwelveBio");
                dispatcher.forward(req, resp);
                break;
            }
            case "computer":{
                ComputerScience cs = new ComputerScience();
                cs.setRegno(Integer.parseInt(regno));
                cs.setName(name);
                cs.setTmarks(Double.parseDouble(tamil));
                cs.setEmarks(Double.parseDouble(english));
                cs.setMmarks(Double.parseDouble(maths));
                cs.setPmarks(Double.parseDouble(physics));
                cs.setCmarks(Double.parseDouble(chemistry));
                cs.setCsmarks(Double.parseDouble(computer));
                double totalCs = cs.getTmarks() + cs.getEmarks() + cs.getMmarks() + cs.getPmarks() + cs.getCmarks() + cs.getCsmarks();
                cs.setTotal(totalCs);

                et.begin();
                em.persist(cs);
                et.commit();
                RequestDispatcher dispatcher=req.getRequestDispatcher("TwelveCs");
                dispatcher.forward(req, resp);
                break;
            }

            case "commerce":{
                Commerce c = new Commerce();
                c.setRegno(Integer.parseInt(regno));
                c.setName(name);
                c.setTmarks(Double.parseDouble(tamil));
                c.setEmarks(Double.parseDouble(english));
                c.setCommarks(Double.parseDouble(commerce));
                c.setAccmarks(Double.parseDouble(acc));
                c.setBmmarks(Double.parseDouble(bm));
                c.setEcomarks(Double.parseDouble(eco));
                double totalCommerce = c.getTmarks() + c.getEmarks() + c.getEcomarks() + c.getCommarks() + c.getAccmarks() + c.getBmmarks();
                c.setTotal(totalCommerce);

                et.begin();
                em.persist(c);
                et.commit();
                RequestDispatcher dispatcher=req.getRequestDispatcher("TwelveCom");
                dispatcher.forward(req, resp);
                break;
            }
            default:
                PrintWriter out = resp.getWriter();
                out.print("<script>alert('Invalid Option')</script>");
                break;
        }
    }
}

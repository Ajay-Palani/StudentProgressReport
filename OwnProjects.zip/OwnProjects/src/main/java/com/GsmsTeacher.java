package com;


import java.sql.*;
import java.util.ArrayList;

public class GsmsTeacher {
	public static Connection establishConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection c =DriverManager.getConnection("jdbc:mysql://localhost:3306/teacher_db","root", "root");
			return c;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void saveUser(Teacher t) {
		Connection c=establishConnection();
		
		try {
			PreparedStatement ps= c.prepareStatement("insert into teacher values(?, ?, ?)");
			ps.setString(1, t.getTname());
			ps.setString(2, t.getEmail());
			ps.setLong(3, t.getPhone());
			System.out.println("Data Saved");
			ps.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public Teacher fetchUserByLogin(String Email, String phone) {
		Connection c=establishConnection();
		try {
			PreparedStatement ps= c.prepareStatement("select * from teacher where Email=? and Phone=?");
			ps.setString(1, Email);
			ps.setString(2, phone);
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				Teacher t=new Teacher();
				t.setEmail(rs.getString("Email"));
				t.setPhone(Long.parseLong(rs.getString("Phone")));
				t.setTname(rs.getString("Name"));
					
				return t;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
}

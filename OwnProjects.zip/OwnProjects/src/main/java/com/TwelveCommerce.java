package com;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/TwelveCom")
public class TwelveCommerce extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("dev2");
		EntityManager em=emf.createEntityManager();
		
		Query q=em.createQuery("select c from Commerce c");
		
		List <Biology> al=q.getResultList();
		
		req.setAttribute("Commerce", al);
		
		
		RequestDispatcher dispatcher=req.getRequestDispatcher("Commerce.jsp");
		dispatcher.forward(req, resp);	
	}
}

package com;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

@Entity
public class Biology {
	@Id
	int regno;
	String name;
	double tmarks;
	double emarks;
	double mmarks;
	double bmarks;
	double pmarks;
	double cmarks;
	double total;
	
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public int getRegno() {
		return regno;
	}
	public void setRegno(int regno) {
		this.regno = regno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getTmarks() {
		return tmarks;
	}
	public void setTmarks(double tmarks) {
		this.tmarks = tmarks;
	}
	public double getEmarks() {
		return emarks;
	}
	public void setEmarks(double emarks) {
		this.emarks = emarks;
	}
	public double getMmarks() {
		return mmarks;
	}
	public void setMmarks(double mmarks) {
		this.mmarks = mmarks;
	}
	public double getBmarks() {
		return bmarks;
	}
	public void setBmarks(double bmarks) {
		this.bmarks = bmarks;
	}
	public double getPmarks() {
		return pmarks;
	}
	public void setPmarks(double pmarks) {
		this.pmarks = pmarks;
	}
	public double getCmarks() {
		return cmarks;
	}
	public void setCmarks(double cmarks) {
		this.cmarks = cmarks;
	}
}

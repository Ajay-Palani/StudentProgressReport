package com;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Ten {
	@Id
	int regno;
	String name;
	double tmarks;
	double emarks;
	double mmarks;
	double smarks;
	double ssmarks;
	double total;
	
	public int getRegno() {
		return regno;
	}
	public void setRegno(int regno) {
		this.regno = regno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getTmarks() {
		return tmarks;
	}
	public void setTmarks(double tmarks) {
		this.tmarks = tmarks;
	}
	public double getEmarks() {
		return emarks;
	}
	public void setEmarks(double emarks) {
		this.emarks = emarks;
	}
	public double getMmarks() {
		return mmarks;
	}
	public void setMmarks(double mmarks) {
		this.mmarks = mmarks;
	}
	public double getSmarks() {
		return smarks;
	}
	public void setSmarks(double smarks) {
		this.smarks = smarks;
	}
	public double getSsmarks() {
		return ssmarks;
	}
	public void setSsmarks(double ssmarks) {
		this.ssmarks = ssmarks;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
}

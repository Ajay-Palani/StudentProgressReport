package com;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/teacher")
public class TeacherLogin extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        String name = req.getParameter("tname");
        String email = req.getParameter("email");
        String phone = req.getParameter("phone");

        PrintWriter out = res.getWriter();
        GsmsTeacher g = new GsmsTeacher();
        Teacher t = new Teacher();
        t.setTname(name);
        t.setEmail(email);
        t.setPhone(Long.parseLong(phone));

        g.saveUser(t);
        RequestDispatcher dispatcher = req.getRequestDispatcher("Teacher.jsp");
        dispatcher.forward(req, res);
    }
}

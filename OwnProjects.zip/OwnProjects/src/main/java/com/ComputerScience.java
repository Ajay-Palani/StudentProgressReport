package com;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ComputerScience {
	@Id
	int regno;
	String name;
	double tmarks;
	double emarks;
	double mmarks;
	double csmarks;
	double pmarks;
	double cmarks;
	double total;
	public int getRegno() {
		return regno;
	}
	public void setRegno(int regno) {
		this.regno = regno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getTmarks() {
		return tmarks;
	}
	public void setTmarks(double tmarks) {
		this.tmarks = tmarks;
	}
	public double getEmarks() {
		return emarks;
	}
	public void setEmarks(double emarks) {
		this.emarks = emarks;
	}
	public double getMmarks() {
		return mmarks;
	}
	public void setMmarks(double mmarks) {
		this.mmarks = mmarks;
	}
	public double getCsmarks() {
		return csmarks;
	}
	public void setCsmarks(double csmarks) {
		this.csmarks = csmarks;
	}
	public double getPmarks() {
		return pmarks;
	}
	public void setPmarks(double pmarks) {
		this.pmarks = pmarks;
	}
	public double getCmarks() {
		return cmarks;
	}
	public void setCmarks(double cmarks) {
		this.cmarks = cmarks;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
	

}

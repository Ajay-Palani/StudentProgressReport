package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/BiologyData")
public class BiologyStudentsData extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("dev1");
		EntityManager em=emf.createEntityManager();
		
		Query q=em.createQuery("select b from Biology b");
		
		List <Biology> al=q.getResultList();
		
		req.setAttribute("Biology", al);
		
		
		RequestDispatcher dispatcher=req.getRequestDispatcher("BiologyData.jsp");
		dispatcher.forward(req, resp);	
	}
}

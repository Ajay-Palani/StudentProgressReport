package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/standard")
public class Standard extends HttpServlet{
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException {
		String std=req.getParameter("class");
		
		PrintWriter out=res.getWriter();
		
		if(std.equals(10)){
			RequestDispatcher dispatcher=req.getRequestDispatcher("Ten.jsp");
			dispatcher.forward(req, res);
		}
		else if(std.equals(11)) {
			RequestDispatcher dispatcher=req.getRequestDispatcher("Eleven.jsp");
			dispatcher.forward(req, res);
		}
		else if(std.equals(12)) {
			RequestDispatcher dispatcher=req.getRequestDispatcher("Twelve.jsp");
			dispatcher.forward(req, res);
		}
		else {
			out.print("<script>");
			out.print("alert(Invalid Class)");
			out.print("</script>");
			RequestDispatcher dispatcher=req.getRequestDispatcher("WelcomeT.jsp");
			dispatcher.include(req, res);
		}
		
	}

}

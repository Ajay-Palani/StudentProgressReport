package com;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/tlogin")
public class TLogin extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        String email = req.getParameter("email");
        String phone = req.getParameter("phone");

        PrintWriter out = res.getWriter();
        GsmsTeacher gt = new GsmsTeacher();
        Teacher t = gt.fetchUserByLogin(email, phone);

        if (t != null) {
            if (email.equals(t.getEmail())) {
                if (phone.equals(String.valueOf(t.getPhone()))) {
                    req.setAttribute("TeacherName", t.getTname());
                    RequestDispatcher dispatcher = req.getRequestDispatcher("WelcomeT.jsp");
                    dispatcher.forward(req, res);
                } else {
                    out.print("<script>alert('Phone not found');</script>");
                    RequestDispatcher dispatcher = req.getRequestDispatcher("Teacher.jsp");
                    dispatcher.include(req, res);
                }
            } else {
                out.print("<script>alert('Email not found');</script>");
                RequestDispatcher dispatcher = req.getRequestDispatcher("Teacher.jsp");
                dispatcher.include(req, res);
            }
        } else {
            out.print("<script>alert('User not found');</script>");
            RequestDispatcher dispatcher = req.getRequestDispatcher("Teacher.jsp");
            dispatcher.include(req, res);
        }
    }
}

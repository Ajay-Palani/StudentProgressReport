package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/login")
public class LoginGsms extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException{

		String email=req.getParameter("email");
		String password=req.getParameter("password");
		
		DbGsms g=new DbGsms();
		GsmsDetails d=g.fetchUserByLogin(email, password);
		
		
		PrintWriter out=res.getWriter();
		
		if (d != null && email.equals(d.getEmail())) {
			if (d!=null && password.equals(d.getPassword())) {
				req.setAttribute("Username", d.getUname());
				RequestDispatcher dispatcher = req.getRequestDispatcher("Welcome.jsp");
				dispatcher.forward(req, res);
			} else {
				out.print("<script>");
				out.print("alert('Incorrect Password')");
				out.print("</script>");
				RequestDispatcher dispatcher = req.getRequestDispatcher("Gsms.jsp");
				dispatcher.include(req, res);
			}
		} else {
			out.print("<script>");
			out.print("alert('Email not Found')");
			out.print("</script>");
			RequestDispatcher dispatcher = req.getRequestDispatcher("Gsms.jsp");
			dispatcher.include(req, res);
		}
	}
}


package com;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Commerce {
	@Id
	int regno;
	String name;
	double tmarks;
	double emarks;
	double commarks;
	double bmmarks;
	double accmarks;
	double ecomarks;
	double total;
	public int getRegno() {
		return regno;
	}
	public void setRegno(int regno) {
		this.regno = regno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getTmarks() {
		return tmarks;
	}
	public void setTmarks(double tmarks) {
		this.tmarks = tmarks;
	}
	public double getEmarks() {
		return emarks;
	}
	public void setEmarks(double emarks) {
		this.emarks = emarks;
	}
	public double getCommarks() {
		return commarks;
	}
	public void setCommarks(double commarks) {
		this.commarks = commarks;
	}
	public double getBmmarks() {
		return bmmarks;
	}
	public void setBmmarks(double bmmarks) {
		this.bmmarks = bmmarks;
	}
	public double getAccmarks() {
		return accmarks;
	}
	public void setAccmarks(double accmarks) {
		this.accmarks = accmarks;
	}
	public double getEcomarks() {
		return ecomarks;
	}
	public void setEcomarks(double ecomarks) {
		this.ecomarks = ecomarks;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}	
}
